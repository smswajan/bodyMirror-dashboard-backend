from .dataset import Dataset, DatasetError
import os
import numpy as np
import scipy.io
import mat73

class Parkinson1(Dataset):
    """Parkinson dataset.


    """

    def __init__(self, base_dir, identifier, **kwargs):
        """Initialize Parkinson dataset without loading it.

        Args:
            base_dir (str): The path to the base directory in which the GrazB dataset resides.
            identifier (str): String identifier for the dataset, e.g. `B01`
            **kwargs: Arbitrary keyword arguments (unused).

        """
        super().__init__()

        #super(Parkinson1, self).__init__(**kwargs)

        self.base_dir = base_dir
        self.data_id = identifier
        self.data_dir = base_dir
        self.data_type = 'EEG'
        self.data_name = 'Parkinson1'

        # sampling frequency (in Hz)
        self.expected_freq_s = 500

        # the graz dataset is split into T and E files
        if self.data_id=='UNMDataset':
            self.fT = os.path.join(self.data_dir, "{id}/Organized_data/EEG_Jim_rest_Unsegmented_WithAllChannels.mat".format(id=self.data_id))
        elif self.data_id=='IowaDataset':
            self.fE = os.path.join(self.data_dir, "{id}/Organized data/IowaData.mat".format(id=self.data_id))
        else:
             raise DatasetError("Parkinson Dataset ({id}) file is unavailable".format(id=self.data_id))

        # variables to store data
        self.raw_data = None
        self.channels_training = None
        self.channels_test = None
        self.sampling_freq = None
        self.labels = np.asarray([])
        self.trials = np.asarray([])


    def load(self, **kwargs):
        """Load a dataset.

        Args:
            **kwargs: Arbitrary keyword arguments (unused).

        Returns:
            Instance to the dataset (i.e. `self`).

        """
        self.sampling_freq = self.expected_freq_s
        if self.data_id=='UNMDataset':
            mat1 = mat73.loadmat(self.fT)['EEG']
            self.raw_data = np.array(mat1)
            self.channels_training= np.array(mat73.loadmat(self.fT)['Channel_location'])
        elif self.data_id=='IowaDataset':
            
            mat2 = mat73.loadmat(self.fE)['EEG']
            self.raw_data = np.array(mat2)
            self.channels_test = np.array(mat73.loadmat(self.fE)['Channel_location'])

        return self

