BodyMirror-realtime
==============

This repository contains scripts to use ``BodyMirror`` in real-time scenarios. This
is, for instance, the case when you want to perform live recording or decoding
of EEG/EMG signals.

Note that the code is already usable, but may not yet be production quality.




