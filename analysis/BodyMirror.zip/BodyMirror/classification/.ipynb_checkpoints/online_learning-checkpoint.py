"""Implementations of common classifiers.

The implementations rely mostly on scikit-learn. They use default parameters
that were found to work on most datasets.
"""

# TODO: check consistency in variable naming
# TODO: implement unit tests

from sklearn.ensemble import RandomForestClassifier as _RandomForestClassifier
import sklearn 
from sklearn.metrics import classification_report
from sklearn.linear_model import SGDClassifier
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB

class ClassifierError(Exception):
    pass

class incremental_classifier():
    """
    Incremental learning 
    """

    def __init__(self, clf_name, **kwargs):
        """Initialize a K Nearest Neighbors (KNN) classifier.

        All additional keyword arguments will be forwarded to the underlying
        classifier, which is here ``sklearn.neighbors.KNeighborsClassifier``.

        Keyword Arguments
        -----------------
        n_neighbors: int, default 5
            Number of neighbors
        """
        self.clf_name=clf_name
        super().__init__()
        if self.clf_name=="SGD":
            
            self.clf = SGDClassifier(random_state=42, **kwargs)

        elif self.clf_name=="RF": 
            
            self.n_estimators = kwargs.pop('n_estimators', 1000)
            self.clf=_RandomForestClassifier(n_estimators=self.n_estimators, n_jobs=-1,  
                                    warm_start=True, random_state=1514, **kwargs)
        elif self.clf_name=="NaiveBayes": 
            self.clf = GaussianNB()

        else: 
            raise ClassifierError("Classifier {clf_name} is not defined")
           
            
    def run(self, X_train, Y_train, X_test, Y_test, **kwargs):

        self.clf.partial_fit(X_train, Y_train.astype(int), classes=np.unique(Y_train))
            
        Y_pred = self.clf.predict(X_test)
        self.n_correct = len(np.where(Y_test - Y_pred== 0)[0])
        self.accuracy = (self.n_correct / len(Y_pred)) * 100.0
        self.report = classification_report(Y_test, Y_pred)
        return self.accuracy, self.report, self.clf


