"""
Implementations of Different optimization models
"""

from sklearn.svm import SVC as _SVC
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score
from sklearn import neighbors
from sklearn.neural_network import MLPClassifier as _MLPClassifier
from sklearn.linear_model import LogisticRegression as _LogisticRegression
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as _LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis as _QuadraticDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB as _GaussianNB
from sklearn.ensemble import RandomForestClassifier as RFC
from sklearn.tree import DecisionTreeClassifier as _DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from bayes_opt import BayesianOptimization
from bayes_opt.util import Colours
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV 
from sklearn.svm import SVC 
from sklearn.linear_model import SGDClassifier 
import parfit.parfit as pf   

    
class Optimizer():
    """
    Bayesian optimization

    """

    def __init__(self, kfolds, **kwargs):

        self.kfolds=kfolds 
        super(Optimizer, self).__init__()
    def bayesian_optimizer(self, data, targets):
        def svc_cv(C, gamma, data, targets):
            """SVC cross validation.
            This function will instantiate a SVC classifier with parameters C and
            gamma. Combined with data and targets this will in turn be used to perform
            cross validation. The result of cross validation is returned.
            Our goal is to find combinations of C and gamma that maximizes the roc_auc
            metric.
            """
            estimator = SVC(C=C, gamma=gamma, random_state=2)
            cval = cross_val_score(estimator, data, targets, scoring='accuracy', cv=self.kfolds)
            return cval.mean()


        def rfc_cv( n_estimators, min_samples_split, max_features, data, targets):
            """Random Forest cross validation.
            This function will instantiate a random forest classifier with parameters
            n_estimators, min_samples_split, and max_features. Combined with data and
            targets this will in turn be used to perform cross validation. The result
            of cross validation is returned.
            Our goal is to find combinations of n_estimators, min_samples_split, and
            max_features that minimzes the log loss.
            """
            estimator = RFC(
                n_estimators=n_estimators,
                min_samples_split=min_samples_split,
                max_features=max_features,
                random_state=2
            )
            cval = cross_val_score(estimator, data, targets,
                                   scoring='accuracy', cv=self.kfolds)
            return cval.mean()


        def optimize_svc(data, targets):
            """Apply Bayesian Optimization to SVC parameters."""
            def svc_crossval(expC, expGamma):
                """Wrapper of SVC cross validation.
                Notice how we transform between regular and log scale. While this
                is not technically necessary, it greatly improves the performance
                of the optimizer.
                """
                C = 10 ** expC
                gamma = 10 ** expGamma
                return svc_cv(C=C, gamma=gamma, data=data, targets=targets)

            optimizer1 = BayesianOptimization(
                f=svc_crossval,
                pbounds={"expC": (-15, 15), "expGamma": (-15, 15)},
                random_state=1234,
                verbose=2
            )
            optimizer1.maximize(n_iter=10)

            print("Final result:", optimizer1.max)
            return optimizer1

        def optimize_rfc(data, targets):
            """Apply Bayesian Optimization to Random Forest parameters."""
            def rfc_crossval(n_estimators, min_samples_split, max_features):
                """Wrapper of RandomForest cross validation.
                Notice how we ensure n_estimators and min_samples_split are casted
                to integer before we pass them along. Moreover, to avoid max_features
                taking values outside the (0, 1) range, we also ensure it is capped
                accordingly.
                """
                return rfc_cv(
                    n_estimators=int(n_estimators),
                    min_samples_split=int(min_samples_split),
                    max_features=max(min(max_features, 0.999), 1e-3),
                    data=data,
                    targets=targets,
                )

            optimizer2 = BayesianOptimization(
                f=rfc_crossval,
                pbounds={
                    "n_estimators": (10, 250),
                    "min_samples_split": (2, 25),
                    "max_features": (0.1, 0.999),
                },
                random_state=1234,
                verbose=2
            )
            optimizer2.maximize(n_iter=10)
            print("Final result:", optimizer2.max)
            return optimizer2
        
        print(Colours.yellow("--- Optimizing SVM using Bayesian Optimization ---"))
        c=optimize_svc(data, targets)

        print(Colours.green("--- Optimizing Random Forest using Bayesian Optimization ---"))
        b=optimize_rfc(data, targets)
        return b, c
    
    def gridsearch_optimizer(self, data, targets, **kwargs):
        # GRID SEARCH 
        if kwargs.get('classifier')=='RandomForest':
            grid_list = {'n_estimators': [10, 100, 1000], 'criterion': ['gini', 'entropy']}
            clf=RFC() 
        elif kwargs.get('classifier')=='SVM':
            
            grid_list = {'kernel': ['rbf', 'sigmoid', 'linear'],"C": [1e1, 1e2, 1e3],
                         "gamma": [1e3, 1e2, 1, 1e-1, 1e-2]}
            clf=SVC(probability = True, random_state = 1)
        elif kwargs.get('classifier')=='SGD':
            

            grid_list = {'alpha': [1e-06, 1e-05, 0.0001,0.001, 0.01, 0.1, 1], 'l1_ratio': 
                         [0, 0.05, 0.1, 0.2, 0.5, 0.8, 0.9, 0.95, 1]}
            clf = SGDClassifier(max_iter=1000, random_state=0)
        else:
            raise Exception ('classifier is not defined')
 
        grid_search = GridSearchCV(clf, param_grid = grid_list, n_jobs = -1, cv = self.kfolds, random_state=0)
          
        print(Colours.yellow("--- Optimizing %s classifier using grid Search ---"% kwargs.get('classifier')))
        grid_search.fit(data, targets) 
        grid_search.best_params_
        means =  grid_search.cv_results_['mean_test_score']
        stds = grid_search.cv_results_['std_test_score']
        for mean, std, params in zip(means, stds, grid_search.cv_results_['params']):
                print("%0.3f (+/-%0.03f) for %r"% (mean, std * 2, params))
                print()
        return grid_search.best_params_
        
    
    def randomResearch_optimizer(self, data, targets, data_test, targets_test, **kwargs):
           # GRID SEARCH 
        if kwargs.get('classifier')=='RandomForest':
            rand_list = {'n_estimators': [10, 100, 1000], 'criterion': ['gini', 'entropy']}
            clf=RFC() 
        elif kwargs.get('classifier')=='SVM':     
            rand_list = {'kernel': ['rbf', 'sigmoid', 'linear'],"C": [1e1, 1e2, 1e3],
                         "gamma": [1e3, 1e2, 1, 1e-1, 1e-2]}
            clf=SVC(probability = True, random_state = 1)
        elif kwargs.get('classifier')=='SGD':
    
            rand_list = {'alpha': [1e-06, 1e-05, 0.0001,0.001, 0.01, 0.1, 1], 'l1_ratio': 
                         [0, 0.05, 0.1, 0.2, 0.5, 0.8, 0.9, 0.95, 1]}
            clf = SGDClassifier(max_iter=1000, random_state=0)
    
        else:
            raise Exception ('classifier is not defined')
            
        rand_search = RandomizedSearchCV(clf, param_distributions = rand_list, n_iter = 20, n_jobs = -1, 
                                         cv = self.kfolds, random_state=0) 
        rand_search.fit(data, targets) 
        rand_search.best_params_
        means =  rand_search.cv_results_['mean_test_score']
        stds = rand_search.cv_results_['std_test_score']
        for mean, std, params in zip(means, stds, rand_search.cv_results_['params']):
                print("%0.3f (+/-%0.03f) for %r"% (mean, std * 2, params))

        return rand_search.best_params_
