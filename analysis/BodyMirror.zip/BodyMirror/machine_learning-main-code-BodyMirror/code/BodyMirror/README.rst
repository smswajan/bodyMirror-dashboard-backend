BodyMirror
=====

``BodyMirror`` is a Python 3 software for processing biosignals.

``BodyMirror`` contains implementations of several functions that are commonly used
during EEG, ECG, saliva and EMG decoding. For this purpose it heavily relies on other
numerical and scientific libraries, for instance ``numpy``, ``scipy``, or
``scikit-learn``, to name just a few. 

:license: Proprietary License



Documentation
=============

You can find documentation for BodyMirror in subfolder
``documentation``. For examples, see the folder ``examples``.


Contributing
============

If you are a Myelin-H developper: 

Please make sure that you follow PEP8, or have a look at the formatting of
BodyMirror's code, and include proper documentation both in your commit messages as
well as the source code. We use Google docstrings for formatting, and
auto-generate parts of the documentation with sphinx.


BodyMirror core developer and contributor
======================================
* Zied Tayeb
* Samaher Garbaya



License
=======

* All code in this repository is published under a specific Proprietary License.
  For more details see the LICENSE file.


