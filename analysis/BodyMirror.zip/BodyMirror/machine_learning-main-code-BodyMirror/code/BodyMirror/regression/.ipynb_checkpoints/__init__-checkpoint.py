# import all functions and ABCs for convenience
from .regressor import regress, Regressor, RegressionResult, register_regressor, available_regressors

from .common import TreeRegressor,  LinearRegressor, RigideRegressor, GradientRegressor, MultiTaskElasticNet