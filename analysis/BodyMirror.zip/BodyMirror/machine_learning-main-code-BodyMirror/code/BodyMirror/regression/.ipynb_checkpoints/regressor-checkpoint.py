from abc import ABC, abstractmethod
from sklearn.metrics import classification_report
from sklearn.ensemble import VotingClassifier
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
import numpy as np
# Importing Modules
from sklearn import datasets
from sklearn.cluster import KMeans
from scipy.cluster.hierarchy import linkage, dendrogram
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import datasets
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score

class RegressorError(Exception):
    pass


class Regressor(ABC):
    """
    Abstract base class representing a regressor.

    All regressors should subclass from this baseclass. All subclasses need to
    implement `run()`, which will be called for the regression. Additional
    arguments to the initialization should be captured via `**kwargs`. 


    """

    def __init__(self):
        pass


    @staticmethod
    def static_opts(**kwargs):
        """
        Returns:
            A kwargs dictionary that can be passed to ``__init__``
        """
        return {}


    @abstractmethod
    def run(self, X_train, Y_train, X_test, Y_test, **kwargs):
        """
        Run a regression.

        Args:
            self: reference to object
            X_train: training data (values)
            Y_train: training data (real-values)
            X_test: evaluation data (values)
            Y_test: evaluation data (real-values)
            **kwargs: Any additional arguments that may be passed to a regressor

        Returns:
            2-element tuple containing

            - **RegressionResult**: Object with all the classification results
            - **Regressor**: Reference to the classifier

        """
        return None, self


    def __call__(self, X_train, Y_train, X_test, Y_test, **kwargs):
        return self.run(X_train, Y_train, X_test, Y_test)


class RegressionResult:
    """
    The result of a regression run.

    The result includes the accuracy of the regression, a reference to the y
    data, as well as the prediction.

    """

    def __init__(self, test, pred):
        self.test = test
        self.pred = pred
        self.score = mean_squared_error(test, pred)
        #percentage of explained variance of the predictions
        self.r2_score= r2_score(test, pred)



# list of known classifiers.
available_regressors = {}


def register_regressor(reg):
    """Automatically register a class in the regressors dictionary.

    This function should be used as decorator.

    Args:
        cls: subclass of `gumpy.regression.regressor` that should be
            registered to gumpy.

    Returns:
        The regressor that was passed as argument

    Raises:
        RegressorError: This error will be raised when a regressor is
            registered with a name that is already used.

    """
    if reg.__name__ in available_regressors:
        raise RegressorError("Regressor {name} already exists in available_regressors".format(name=cls.__name__))

    available_regressors[reg.__name__] = reg
    return reg

def regress(c, *args, **kwargs):
    """Regress EEG data given a certain regressor.

    The regressor can be specified by a string or be passed as an object. The
    latter option is useful if a classifier has to be called repeatedly, but the
    instantiation is computationally expensive.

    Additional arguments for the classifier instantiation can be passed in
    kwargs as a dictionary with name `opts`. They will be forwarded to the
    classifier on construction. If the classifier was passed as object, this
    will be ignored.

    Args:
        c (str or object): The regressor. Either specified by the regressor
            name, or passed as object
        X_train: training data (values)
        Y_train: training data (labels)
        X_test: evaluation data (values)
        Y_test: evaluation data (labels)
        **kwargs: additional arguments that may be passed on to the regressor. If the
            Regressor is selected via string/name, you can pass options to the
         

    Returns:
        2-element tuple containing

        - **RegressionResult**: The result of the classification.
        - **Regressor**:  The classifier that was used during the classification.

    Raises:
        RegressorError: If the classifier is unknown or classification fails.

    Examples:
        >>> import BodyMirror
        >>> result, clf = BodyMirror.regress ("SVM", X_train, Y_train, X_test, Y_test)

    """

    if isinstance(c, str):
        if not (c in  available_regressors):
            raise RegressorError("Unknown Regressor {c}".format(c=c.__repr__()))

        # instantiate the classifier
        opts = kwargs.pop('opts', None)
        if opts is not None:
            reg =   available_regressors[c](**opts)
        else:
            reg =  available_regressors[c]()
        return reg.run(*args, **kwargs)

    elif isinstance(c, Regressor):
        return c.run(*args, **kwargs)

    # invalid argument passed to the function
    raise RegressorError("Unknown Regressor {c}".format(c=c.__repr__()))

