"""Implementations of common regressors.

The implementations rely mostly on scikit-learn. They use default parameters
that were found to work on most datasets.
"""


from .regressor import Regressor, RegressionResult, register_regressor
from sklearn.linear_model import LinearRegression
from sklearn import linear_model
from sklearn.tree import DecisionTreeRegressor
from sklearn import ensemble


@register_regressor
class TreeRegressor(Regressor):
    """
    """

    def __init__(self, **kwargs):
        """
        """

        super(TreeRegressor, self).__init__()
        self.max_depth = kwargs.pop('max_depth', 5)
        self.reg = DecisionTreeRegressor(max_depth=self.max_depth, **kwargs)


    def run(self, X_train, Y_train, X_test, Y_test, **kwargs):
        self.reg.fit(X_train, Y_train)
        Y_pred = self.reg.predict(X_test)
        return RegressionResult(Y_test, Y_pred), self
    
    
@register_regressor
class LinearRegressor(Regressor):
    """
    LinearRegression will take in its fit method arrays X, y and will store the coefficients of the linear model in its coef_ 
    """

    def __init__(self, **kwargs):
        """
        """

        super(LinearRegressor, self).__init__()
        self.reg = linear_model.LinearRegression(**kwargs)


    def run(self, X_train, Y_train, X_test, Y_test, **kwargs):
        self.reg.fit(X_train, Y_train)
        Y_pred = self.reg.predict(X_test)
        coefficients= self.reg.coef_
        return RegressionResult(Y_test, Y_pred), self, coefficients


@register_regressor
class RigideRegressor(Regressor):
    """
    Ridge regression addresses some of the problems of Ordinary Least Squares by imposing a penalty on the size of coefficients
    """

    def __init__(self, **kwargs):
        """
        Alpha is a complexity parameter that controls the amount of shrinkage: the larger the value of , 
        the greater the amount of shrinkage and thus the coefficients become more robust to collinearity.
        """

        super(RigideRegressor, self).__init__()
        self.reg = linear_model.Ridge(alpha=.5, **kwargs)


    def run(self, X_train, Y_train, X_test, Y_test, **kwargs):
        self.reg.fit(X_train, Y_train)
        Y_pred = self.reg.predict(X_test)
        coefficients= self.reg.coef_
        return RegressionResult(Y_test, Y_pred), self, coefficients
    

@register_regressor
class GradientRegressor(Regressor):
    """
    """

    def __init__(self, **kwargs):
        """
        """

        super(GradientRegressor, self).__init__()
        params = {'n_estimators': 500, 'max_depth': 4, 'min_samples_split': 2,
          'learning_rate': 0.01, 'loss': 'ls'}
        self.reg = ensemble.GradientBoostingRegressor(**params)


    def run(self, X_train, Y_train, X_test, Y_test, **kwargs):
        self.reg.fit(X_train, Y_train)
        Y_pred = self.reg.predict(X_test)
        #coefficients= self.reg.coef_
        return RegressionResult(Y_test, Y_pred), self

      

@register_regressor
class MultiTaskElasticNet(Regressor):
    """
    The MultiTaskLasso is a linear model that estimates sparse coefficients for multiple regression problems jointly:
    y is a 2D array, of shape (n_samples, n_tasks). 
    The constraint is that the selected features are the same for all the regression problems, also called tasks.
    """

    def __init__(self, **kwargs):
        """
        """

        super(LinearRegressor, self).__init__()
        self.reg = linear_model.MultiTaskElasticNet(alpha=0.1, **kwargs)


    def run(self, X_train, Y_train, X_test, Y_test, **kwargs):
        self.reg.fit(X_train, Y_train)
        Y_pred = self.reg.predict(X_test)
        coefficients= self.reg.coef_
        return RegressionResult(Y_test, Y_pred), self, coefficients
    
    
