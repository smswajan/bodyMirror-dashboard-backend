import numpy as np
from sklearn.metrics import silhouette_score
from scipy.spatial.distance import euclidean
from sklearn.cluster import KMeans

from sklearn.cluster import KMeans
from scipy.cluster.hierarchy import linkage, dendrogram
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt


class Clustering:
    """
    K-means is a clustering algorithm that finds convex clusters. 
    
    The user specifies the number of clusters a priori."""

    def __init__(self, K=2, init="k++", random_state=42):
        self.K_ = K
        self.init_ = init
        self._seed = random_state
        self.centroid_init_ = None
        self.centroid_loc_ = None
        self._centroid_test = None
        self._nrows = None
        self._nfeatures = None
        self.count_ = None
        self.inertia_ = None
        self.silhouette_ = None

    def _k_plus_plus(self, X, k):
        """
        k++ implementation for cluster initialization

        Input:
            X = numpy data matrix
            k = number of centroids
        Output:
            k++ selected centroid indices
        """
        n_clust = 0
        idx = np.arange(len(X))

        while n_clust < k:
            # initialize
            if n_clust == 0:
                choice = np.random.choice(idx, size=1)
                cluster_idx = np.array(choice)
            else:
                distances = np.array([euclidean(X[choice], X[i]) for i in range(len(X))])
                for i, _ in enumerate(distances):
                    if i in cluster_idx:
                        distances[i] = 0
                total_distance = np.sum(distances)
                prob = np.array([distance / total_distance for distance in distances])
                choice = np.random.choice(idx, size=1, p=prob)
                if choice not in cluster_idx:
                    cluster_idx = np.append(cluster_idx, choice)
                    np.delete(idx, choice)
            n_clust = len(cluster_idx)
        return cluster_idx

    def _initialize_centroids(self, X, seed=True):
        """
        Randomly initialize centroids.
        
        Input:
            X = numpy data matrix
        Output:
            K centroid locations
        """
        if seed == True:
            np.random.seed(self._seed)

        self._nrows = X.shape[0]
        self._nfeatures = X.shape[1]

        assert (
            self.init_ == "random" or "k++" or "forgy"
        ), "choose 'random', 'k++', 'forgy' for init"

        if self.init_ == "random":
            centroid_locs = [
                np.random.randint(low=np.min(X), high=np.max(X), size=self._nfeatures)
                for _ in range(self.K_)
            ]
        elif self.init_ == "k++":
            centroid_locs = X[self._k_plus_plus(X, self.K_)]

            self.centroid_loc_ = centroid_locs
        elif self.init_ == "forgy":
            centroid_locs = X[np.random.choice(self._nrows, replace=False, size=self.K_)]

        self.centroid_loc_ = centroid_locs
        self.centroid_init_ = np.array(centroid_locs).reshape(self.K_, -1)

    def _calc_distance(self, X):
        """
        Calculate the distance between data points and centroids.
        
        Input:
            X = numpy data matrix
        Output:
            matrix of distance between each data point and each cluster
        """
        return np.array(
            [
                euclidean(X[i], self.centroid_loc_[j])
                for i in range(self._nrows)
                for j in range(self.K_)
            ]
        ).reshape(self._nrows, self.K_)

    def _update_cluster_loc(self, X):
        """
        Update centroid locations for each iteration of fitting.
        
        Input:
            X = numpy data matrix
        Output:
            updated centroid location
        """
        predictions = self.predict(X)
        idx = set(predictions)
        assert idx != self.K_, "Bad initialization: use 'k++' or 'forgy' init"
        self.centroid_loc_ = np.array(
            [np.mean(X[self.predict(X) == i], axis=0) for i in range(self.K_)]
        ).reshape(len(idx), -1)

    def fit(self, X):
        """
        Calculate centroid positions given training data.
        
        Input:
            X = numpy data matrix
        Output:
            fitted centroid locations
        """
        self._initialize_centroids(X, seed=True)
        self.count_ = 0
        while True:
            self.count_ += 1
            self._centroid_test = self.centroid_loc_
            self._update_cluster_loc(X)

            if np.all(self._centroid_test == self.centroid_loc_):
                self._inertia(X)
                self._silhouette_score(X)
                break

    def predict(self, X):
        """
        Assign data points to cluster number.
        
        Input:
            X = numpy data matrix
        Output:
            cluster ID
        """
        return np.argmin(self._calc_distance(X), axis=1)

    def _inertia(self, X):
        # underscore means that this is just for internal use
        """
        Calculates the total inertia after fitting."""
        self.inertia_ = np.sum(
            [
                euclidean(X[self.predict(X) == j][i], self.centroid_loc_[j]) ** 2
                for j in range(self.K_)
                for i in range(X[self.predict(X) == j].shape[0])
            ]
        )

    # Need to write this part from scratch
    def _silhouette_score(self, X):
        """
        Calculates the silhouette score after fitting."""
        self.silhouette_ = silhouette_score(X, self.predict(X))

    # Extensions
    # 1. Add multiple initializations to find better clusters
    # 2. Create plot methods
    def optimal_clusterer(self, X, max_clusters=10):
        """
        Iterative K-means clustering that finds optimal # of clusters based on silhouette score.

        Parameters
        ----------
        X: numpy ndarray
            data to cluster on

        max_clusters: int, optional, default: 10 
            max number of clusters to try

        Attributes
        ----------
        best number of clusters

        silhouette score
        """
        score = []
        for i in range(2, max_clusters + 1):
            kmeans = KMeans(n_clusters=i, random_state=42, n_jobs=-1)
            cluster_labels = self.predict(X)
            score.append(silhouette_score(X, cluster_labels))
        return np.argmax(score) + 2, round(max(score), 4)


def Kmeans(n_clusters, X_train, X_test):
    model = KMeans(n_clusters)
    model.fit(X_train)
    # Predicitng a single input
    predicted_label = model.predict(X_test)
    return predicted_label


def HClustering(samples, label_names):
    mergings = linkage(samples, method="complete")
    dendrogram(mergings, labels=label_names, leaf_rotation=90, leaf_font_size=6)

    plt.show()


def tsne(X_train):
    model = TSNE(learning_rate=100)
    transformed = model.fit_transform(X_train)
    return transformed
