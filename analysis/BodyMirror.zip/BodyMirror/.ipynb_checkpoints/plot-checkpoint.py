""" Module for plotting results."""
import seaborn as sns
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import sklearn.metrics as skm
import pandas as pd
import pywt
import scipy.signal
import sklearn.decomposition
import itertools
from sklearn.metrics import confusion_matrix

# TODO: check all variable names and improve them


def ROC_curve(Y_pred, Y_test, fig=None):
    Y_score = np.array(Y_pred)
    # The following were moved inside the function call (roc_curve) to avoid
    # potential side effects of this functin
    # Y_score -=1
    # Y_test -=1

    # print (roc_auc_score(y_test, y_score))

    fpr, tpr, _ = sklearn.metrics.roc_curve(Y_test - 1, Y_score - 1)

    # plotting
    if fig is None:
        fig = plt.figure()
    plt.plot(fpr, tpr, color="red", lw=2)
    plt.plot([0, 1], [0, 1], color="navy", lw=2)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("Roc curve")
    plt.legend(loc="lower right")
    plt.show()


def confusion_matrix(true_labels, predicted_labels, cmap=plt.cm.Blues):
    cm = skm.confusion_matrix(true_labels, predicted_labels)
    # TODO:
    # print(cm)
    # Show confusion matrix in a separate window ?
    plt.matshow(cm, cmap=cmap)
    plt.title("Confusion matrix")
    plt.colorbar()
    plt.ylabel("True label")
    plt.xlabel("Predicted label")
    plt.show()


# TODO: permit the user to specify the figure where this plot shall appear
def accuracy_results_plot(data_path):
    data = pd.read_csv(data_path, index_col=0)
    sns.boxplot(data=data)
    sns.set(rc={"figure.figsize": (9, 6)})
    ax = sns.boxplot(data=data)
    ax.set_xlabel(x_label, fontsize=15)
    ax.set_ylabel(y_label, fontsize=15)
    plt.show()


def reconstruct_without_approx(xs, labels, level, fig=None):
    # reconstruct
    rs = [pywt.upcoef("d", x, "db4", level=level) for x in xs]

    # generate plot
    if fig is None:
        fig = plt.figure()
    for i, x in enumerate(xs):
        plt.plot((np.abs(x)) ** 2, label="Power of reconstructed signal ({})".format(labels[i]))

    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.0)
    return rs, fig


def reconstruct_with_approx(cDs, labels, wavelet, fig=None):
    rs = [pywt.idwt(cA=None, cD=cD, wavelet=wavelet) for cD in cDs]

    if fig is None:
        fig = plt.figure()

    for i, r in enumerate(rs):
        plt.plot((np.abs(r)) ** 2, label="Power of reconstructed signal ({})".format(labels[i]))
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.0)

    return rs, fig


def fft(x, fs, fig_fft=None, fig_psd=None):
    t = np.arange(fs)
    signal_fft = np.fft.fft(x)
    signal_psd = np.abs(signal_fft) ** 2
    freq = np.linspace(0, fs, len(signal_fft))
    freq1 = np.linspace(0, fs, len(signal_psd))

    if fig_fft is None:
        fig_fft = plt.figure()
    plt.plot(freq, signal_fft, label="fft")

    if fig_psd is None:
        fig_psd = plt.figure()
    plt.plot(freq, signal_psd, label="PSD")

    return signal_fft, signal_psd, fig_fft, fig_psd


def dwt(approx, details, labels, level, sampling_freq, class_str=None):
    """
    Plot the results of a DWT transform.
    """

    fig, axis = plt.subplots(level + 1, 1, figsize=(8, 8))
    fig.tight_layout()

    # plot the approximation
    for i, l in enumerate(labels):
        axis[0].plot(approx[i], label=l)
    axis[0].legend()
    if class_str is None:
        axis[0].set_title(
            "DWT approximations (level={}, sampling-freq={}Hz)".format(level, sampling_freq)
        )
    else:
        axis[0].set_title(
            "DWT approximations, {} (level={}, sampling-freq={}Hz)".format(
                class_str, level, sampling_freq
            )
        )
    axis[0].set_ylabel("(A={})".format(level))

    # build the rows of detail coefficients
    for j in range(1, level + 1):
        for i, l in enumerate(labels):
            axis[j].plot(details[i][j - 1], label=l)
        if class_str is None:
            axis[j].set_title(
                "DWT Coeffs (level{}, sampling-freq={}Hz)".format(level, sampling_freq)
            )
        else:
            axis[j].set_title(
                "DWT Coeffs, {} (level={}, sampling-freq={}Hz)".format(
                    class_str, level, sampling_freq
                )
            )
        axis[j].legend()
        axis[j].set_ylabel("(D={})".format(j))

    return axis


def welch_psd(xs, labels, sampling_freq, fig=None):
    """Compute and plot the power spectrum density (PSD) using Welch's method.
    """

    fs = []
    ps = []
    for i, x in enumerate(xs):
        f, p = scipy.signal.welch(x, sampling_freq, "flattop", scaling="spectrum")
        fs.append(f)
        ps.append(p)

    if fig is None:
        fig = plt.figure()

    plt.subplots_adjust(hspace=0.4)
    for i, p in enumerate(ps):
        plt.semilogy(f / 8, p.T, label=labels[i])

    plt.xlabel("frequency [Hz]")
    plt.ylabel("PSD")

    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.0)
    plt.grid()
    plt.show()

    return ps, fig


def artifact_removal(X, S, S_reconst, fig=None):
    """Plot the results of an artifact removal.

    This function displays the results after artifact removal, for instance
    performed via :func:`gumpy.signal.artifact_removal`.

    Parameters
    ----------
    X:
        Observations
    S:
        True sources
    S_reconst:
        The reconstructed signal
    """

    if fig is None:
        fig = plt.figure()

    models = [X, S, S_reconst]
    names = ["Observations (mixed signal)", "True Sources", "ICA recovered signals"]
    for ii, (model, name) in enumerate(zip(models, names), 1):
        plt.subplot(3, 1, ii)
        plt.title(name)
    plt.subplots_adjust(0.09, 0.04, 0.94, 0.94, 0.26, 0.46)
    plt.show()


def PCA_2D(X, X_train, Y_train, fig=None, colors=None):
    # computation
    pca_2comp = sklearn.decomposition.PCA(n_components=2)
    X_2comp = pca_2comp.fit_transform(X)

    # color and figure initialization
    if colors is None:
        colors = ["red", "cyan"]
    if fig is None:
        fig = plt.figure()

    # plotting
    fig.suptitle("2D - Data")
    ax = fig.add_subplot(1, 1, 1)
    ax.scatter(
        X_train.T[0], X_train.T[1], alpha=0.5, c=Y_train, cmap=mpl.colors.ListedColormap(colors)
    )
    ax.set_xlabel("x1")
    ax.set_ylabel("x2")


def PCA_3D(X, X_train, Y_train, n_components, fig=None, colors=None):
    # computation
    pca_3comp = sklearn.decomposition.PCA(n_components=n_components)
    X_3comp = pca_3comp.fit_transform(X)

    # color and figure initialization
    if colors is None:
        colors = ["red", "cyan"]
    if fig is None:
        fig = plt.figure()

    # plotting
    fig.suptitle("3D - Data")
    ax = fig.add_subplot(1, 1, 1, projection="3d")
    ax.scatter(
        X_train.T[0],
        X_train.T[1],
        X_train.T[2],
        alpha=0.5,
        c=Y_train,
        cmap=mpl.colors.ListedColormap(colors),
    )
    ax.set_xlabel("x1")
    ax.set_ylabel("x2")
    ax.set_zlabel("x3")


# TODO: allow user to pass formatting control, e.g. colors, cmap, etc
def PCA(ttype, X, X_train, Y_train, fig=None, colors=None):
    plot_fns = {"2D": PCA_2D, "3D": PCA_3D}
    if not ttype in plot_fns:
        raise Exception("Transformation type '{ttype}' unknown".format(ttype=ttype))
    plot_fns[ttype](X, X_train, Y_train, fig, colors)


# TODO: check if this is too specific
# TODO: documentation
# TODO: units missing
def plot_history(history, ytitle, mtitle):
    plt.figure()
    plt.xlabel("Epoch")
    plt.ylabel(ytitle)
    plt.plot(hist["epoch"], hist[mtitle], label="Train Error")
    plt.plot(hist["epoch"], hist[mtitle], label="Val Error")
    plt.legend()
    plt.ylim([0, 50])


def plot_confusion_matrix(
    path, cm, target_names, title="Confusion matrix ", cmap=None, normalize=True
):
    """
    Produces a plot for a confusion matrix and saves it to file.
    Args:
        path (str): Filename of produced plot
        cm (ndarray): confusion matrix from sklearn.metrics.confusion_matrix
        target_names ([str]): given classification classes such as [0, 1, 2] the
            class names, for example: ['high', 'medium', 'low']
        title (str): the text to display at the top of the matrix
        cmap: the gradient of the values displayed from matplotlib.pyplot.cm see
            http://matplotlib.org/examples/color/colormaps_reference.html
            plt.get_cmap('jet') or plt.cm.Blues
        normalize (bool): if False, plot the raw numbers. If True, plot the
            proportions
    Example:
        plot_confusion_matrix(cm           = cm,              # confusion matrix created by
                                                              # sklearn.metrics.confusion_matrix
                          normalize    = True,                # show proportions
                          target_names = y_labels_vals,       # list of names of the classes
                          title        = best_estimator_name) # title of graph
    References:
        http://scikit-learn.org/stable/auto_examples/model_selection/plot_confusion_matrix.html
    """

    accuracy = np.trace(cm) / float(np.sum(cm))
    misclass = 1 - accuracy

    if cmap is None:
        cmap = plt.get_cmap("Blues")

    fig = plt.figure(figsize=(8, 6))
    plt.imshow(cm, interpolation="nearest", cmap=cmap)
    plt.title(title)
    plt.colorbar()

    if target_names is not None:
        tick_marks = np.arange(len(target_names))
        plt.xticks(tick_marks, target_names, rotation=45)
        plt.yticks(tick_marks, target_names)

    if normalize:
        cm = cm.astype("float") / cm.sum(axis=1)[:, np.newaxis]

    thresh = cm.max() / 1.5 if normalize else cm.max() / 2
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        if normalize:
            plt.text(
                j,
                i,
                "{:0.4f}".format(cm[i, j]),
                horizontalalignment="center",
                color="white" if cm[i, j] > thresh else "black",
            )
        else:
            plt.text(
                j,
                i,
                "{:,}".format(cm[i, j]),
                horizontalalignment="center",
                color="white" if cm[i, j] > thresh else "black",
            )

    plt.tight_layout()
    plt.ylabel("True label")
    # plt.xlabel('Predicted label\naccuracy={:0.4f}; misclass={:0.4f}'.format(accuracy, misclass))
    plt.show()
    fig.savefig(path)


# Correlation matric plotting function


def correlation_matrix(data, title, labels):
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    cmap = cm.get_cmap("jet", 30)
    cax = ax1.imshow(data.corr(), interpolation="nearest", cmap=cmap)
    ax1.grid(True)
    plt.title(title)
    ax1.set_xticklabels(labels, fontsize=6)
    ax1.set_yticklabels(labels, fontsize=6)
    # Add colorbar, make sure to specify tick locations to match desired ticklabels
    fig.colorbar(cax, ticks=[0.75, 0.8, 0.85, 0.90, 0.95, 1])
    plt.show()


# Correlation matric plotting function using seaborn


def correlation_matrix_sns(data, annot):
    sns.heatmap(data.corr(), annot=annot)


def plot_bar(Nsubjects, data, colors, ylabel, xlabel, Ly, xticks, title, path):
    ind = np.arange(Nsubjects)
    width = 0.25
    font = {"family": "serif", "weight": "normal", "size": 16}
    fig = plt.figure(figsize=(12, 6))
    ax = plt.subplot(111)
    p1 = ax.bar(ind + 0, data, width, color=colors)
    plt.ylabel(ylabel, fontweight="semibold", labelpad=12)
    plt.xlabel(xlabel, fontweight="semibold", labelpad=12)
    plt.xticks(ind, xticks)
    # Ly: np.arange(0, 3.5, 0.5)
    plt.yticks(Ly)
    axes = plt.gca()
    SMALL_SIZE = 10
    MEDIUM_SIZE = 18
    BIGGER_SIZE = 18
    plt.title(title, fontweight="semibold")
    plt.rc("font", size=MEDIUM_SIZE)  # controls default text sizes
    plt.rc("axes", titlesize=BIGGER_SIZE)  # fontsize of the axes title
    plt.rc("axes", labelsize=BIGGER_SIZE)  # fontsize of the x and y labels
    plt.rc("xtick", labelsize=BIGGER_SIZE)  # fontsize of the tick labels
    plt.rc("ytick", labelsize=BIGGER_SIZE)  # fontsize of the tick labels
    plt.rc("legend", fontsize=BIGGER_SIZE)  # legend fontsize
    plt.rc("figure", titlesize=BIGGER_SIZE)  # fontsize of the figure title
    plt.show()
    fig.savefig(path)


def plot_loss(history):
    historydf = pd.DataFrame(history.history, index=history.epoch)
    plt.figure(figsize=(10, 8))
    historydf.plot(ylim=(0, historydf.values.max()))
    plt.title("Loss: %.3f" % history.history["loss"][-1])


def plot_outputs_autencoders(autoencoder, n, dims, X_test):
    out = autoencoder.predict(X_test)

    # number of example digits to show
    n = 5
    plt.figure(figsize=(10, 4.5))
    for i in range(n):
        # plot original image
        ax = plt.subplot(2, n, i + 1)
        plt.imshow(x_test[i].reshape(*dims))
        plt.gray()
        ax.get_xaxis().set_visible(False)
        ax.get_yaxis().set_visible(False)
        if i == n / 2:
            ax.set_title("Original Images")

        # plot reconstruction
        ax = plt.subplot(2, n, i + 1 + n)
        plt.imshow(out[i].reshape(*dims))
        plt.gray()
        ax.get_xaxis().set_visible(False)
        ax.get_yaxis().set_visible(False)
        if i == n / 2:
            ax.set_title("Reconstructed Images")
    plt.show()


def circular_plot(figsize, data, Nsubjects, ylabel, xlabel, ymax, path_to_save):
    """
     figsize: (height, width)
     data: [(list of accuracy values, list of std values, name of the model)]
     Nsubjects: number of accuracy values 
    """
    sns.set()
    cdict = {}
    lowframe = [0.14, 0.006, 0.79, 0.24]
    upframe = [0.14, 0.25, 0.79, 0.79]
    fig = plt.figure(figsize=figsize)
    ax = plt.axes(upframe, polar=True)
    nsets = float(len(data))
    maxang = 2 * np.pi
    offset = maxang / (Nsubjects + 1)
    wsubj = (maxang - 2 * offset) / Nsubjects
    w = width = wsubj / nsets
    ind = np.mgrid[offset : maxang - wsubj - offset : Nsubjects * 1j]  # arange(Nsubjects)
    means, mins, maxs, cols = [], [], [], []
    for i, (d, dstd, dname) in enumerate(data):
        c = plt.cm.brg(i / nsets)
        p = ax.bar(
            ind + i * w,
            dstd,
            width,
            bottom=np.array(d) - np.array(dstd) / 2.0,
            label=dname,
            color=c,
            align="edge",
            edgecolor="b",
        )  # , yerr=KNNStd)
        #    p=ax.bar(ind+i*w, dstd, width, bottom=np.array(d)-np.array(dstd)/2.,label=dname,color=c) #, yerr=KNNStd)
        means.append(np.median(d))
        mins.append(np.min(d))
        maxs.append(np.max(d))
        cols.append(c)
        cdict[dname] = c
    plt.ylabel(ylabel, rotation=0)
    ax.yaxis.set_label_coords(0.83, 0.485)  # innen:.84, außen:0.898
    ax.yaxis.set_label_position("right")
    ax.yaxis.set_ticks_position("none")
    ax.set_rlabel_position(0)

    plt.xlabel(xlabel, rotation=90)
    ax.xaxis.set_label_coords(-0.145, 0.6)
    ax.set_ylim(ymax // 2, ymax)
    ax.set_yticks(np.arange(60, ymax + 1, 10))
    ax.set_yticklabels(["%i" % i for i in np.arange(60, ymax + 1, 10)])
    ax.set_xticks(np.append(np.append([0], ind), ind[-1:] + offset), minor=False)
    ax.set_xticklabels([""] + ["" for i in range(Nsubjects)], minor=False, visible=False)
    ax.set_xticks(np.append([0], ind + w * nsets / 2.0), minor=True)
    ax.set_xticklabels([""] + ["S%i" % (i + 1) for i in range(Nsubjects)], minor=True)

    ax2 = plt.axes(lowframe, polar=False)
    # ax2.bar(np.arange(len(data))+.5,np.array(maxs)-mins,bottom=mins,color=cols,align="center")
    for i, (m, dst, dname) in enumerate(data):
        barwidths = np.ones_like(m) * 2.0
        ax2.bar(
            np.ones_like(m) * i + 0.5,
            barwidths,
            width=0.8,
            bottom=m - barwidths / 2.0,
            color=cdict[dname],
            align="center",
            alpha=0.5,
        )
    barwidths = np.ones_like(means) * 2.0
    ax2.bar(
        np.arange(len(data)) + 0.5,
        barwidths,
        bottom=np.array(means) - barwidths / 2.0,
        color="k",
        align="center",
    )
    ax2.set_xlim(0, len(data))
    # ax2.set_xlabel("Algorithm",labelpad=0)
    ax2.set_ylim(ymax // 2, ymax)
    ax2.set_ylabel("mean acc. (%)", labelpad=6)

    ax2.xaxis.set_ticklabels([])

    SMALL_SIZE = 8
    MEDIUM_SIZE = 9
    BIGGER_SIZE = 9.5

    for i, (c, D) in enumerate(zip(cols, data)):
        ax2.text(
            i + 0.5,
            100,
            D[2],
            color=c,
            ha="center",
            va="bottom",
            size=BIGGER_SIZE,
            weight="semibold",
        )  #
    plt.legend(loc=(1.2, 0.7))
    plt.show()
    fig.savefig(path_to_save)


def EEG_bandwave_visualizer(data, band_wave, n_trial, lo, hi, fig=None):
    if not fig:
        fig = plt.figure()

    plt.clf()
    plt.plot(
        band_wave[
            data.trials[n_trial]
            - data.mi_interval[0] * data.sampling_freq : data.trials[n_trial]
            + data.mi_interval[0] * data.sampling_freq,
            0,
        ],
        alpha=0.7,
        label="C3",
    )
    plt.plot(
        band_wave[
            data.trials[n_trial]
            - data.mi_interval[0] * data.sampling_freq : data.trials[n_trial]
            + data.mi_interval[0] * data.sampling_freq,
            1,
        ],
        alpha=0.7,
        label="C4",
    )
    plt.plot(
        band_wave[
            data.trials[n_trial]
            - data.mi_interval[0] * data.sampling_freq : data.trials[n_trial]
            + data.mi_interval[0] * data.sampling_freq,
            2,
        ],
        alpha=0.7,
        label="Cz",
    )

    plt.legend()
    plt.title("Filtered data  (Band wave {}-{})".format(lo, hi))


# TODO: check if this is too specific
# TODO: documentation
# TODO: units missing
def average_power(data_class1, lowcut, highcut, interval, sampling_freq, logarithmic_power):
    fs = sampling_freq
    if logarithmic_power:
        power_c3_c1_a = np.log(np.power(data_class1[0], 2).mean(axis=0))
        power_c4_c1_a = np.log(np.power(data_class1[1], 2).mean(axis=0))
        power_cz_c1_a = np.log(np.power(data_class1[2], 2).mean(axis=0))
        power_c3_c2_a = np.log(np.power(data_class1[3], 2).mean(axis=0))
        power_c4_c2_a = np.log(np.power(data_class1[4], 2).mean(axis=0))
        power_cz_c2_a = np.log(np.power(data_class1[5], 2).mean(axis=0))
    else:
        power_c3_c1_a = np.power(data_class1[0], 2).mean(axis=0)
        power_c4_c1_a = np.power(data_class1[1], 2).mean(axis=0)
        power_cz_c1_a = np.power(data_class1[2], 2).mean(axis=0)
        power_c3_c2_a = np.power(data_class1[3], 2).mean(axis=0)
        power_c4_c2_a = np.power(data_class1[4], 2).mean(axis=0)
        power_cz_c2_a = np.power(data_class1[5], 2).mean(axis=0)

    # time indices
    t = np.linspace(
        interval[0], interval[1], len(power_c3_c1_a[fs * interval[0] : fs * interval[1]])
    )

    # first figure, left motor imagery
    plt.figure()
    plt.plot(t, power_c3_c1_a[fs * interval[0] : fs * interval[1]], c="blue", label="C3", alpha=0.7)
    plt.plot(t, power_c4_c1_a[fs * interval[0] : fs * interval[1]], c="red", label="C4", alpha=0.7)
    plt.legend()
    plt.xlabel("Time")
    if logarithmic_power:
        plt.ylabel("Logarithmic Power")
    else:
        plt.ylabel("Power")
    plt.title("Left motor imagery movements ".format(lowcut, highcut))
    plt.show()

    # second figure, right motor imagery
    plt.figure()
    plt.clf()
    plt.plot(t, power_c3_c2_a[fs * interval[0] : fs * interval[1]], c="blue", label="C3", alpha=0.7)
    plt.plot(t, power_c4_c2_a[fs * interval[0] : fs * interval[1]], c="red", label="C4", alpha=0.7)
    plt.legend()
    plt.xlabel("Time")
    if logarithmic_power:
        plt.ylabel("Logarithmic Power")
    else:
        plt.ylabel("Power")
    plt.title("Right motor imagery movements".format(lowcut, highcut))


def plot_spectrogram(spect, title, transpose=False):
    # keeps the color range the same for all spectrograms
    plt.matshow(spect.T if transpose else spect, vmin=-180, vmax=0, cmap=plt.get_cmap("Spectral"))
    plt.title(title)
    plt.colorbar()
    plt.show()
    return plt


def plot_EEG_mean_frequency(data, fs):
    '''
    Data shape: trials*channels*time-points
    return: mean for each band 
    
    '''
    # Get data average of all trials 
    #if average==True:
    data=np.average(data, axis=0)
    print(data.shape)
    #else: 
        #data=data
    # Get real amplitudes of FFT (only in postive frequencies)
    fft_vals = np.absolute(np.fft.rfft(data))
    # Get frequencies for amplitudes in Hz
    fft_freq = np.fft.rfftfreq(len(data), 1.0/fs)
    # Define EEG bands
    eeg_bands = {'Delta': (0, 4),
                 'Theta': (4, 8),
                 'Alpha': (8, 12),
                 'Beta': (12, 30),
                 'Gamma': (30, 40)}
    # Take the mean of the fft amplitude for each EEG band
    eeg_band_fft = dict()
    for band in eeg_bands:  
        freq_ix = np.where((fft_freq >= eeg_bands[band][0]) & 
                           (fft_freq <= eeg_bands[band][1]))[0]
        eeg_band_fft[band] = np.mean(fft_vals[freq_ix])
        
    a1=eeg_band_fft['Alpha']
    a2=eeg_band_fft['Beta']
    a3=eeg_band_fft['Delta']
    a4=eeg_band_fft['Gamma']
    a5=eeg_band_fft['Theta']
    
    # Plot the data (using pandas here)
    df = pd.DataFrame(columns=['band', 'val'])
    df['band'] = eeg_bands.keys()
    df['val'] = [eeg_band_fft[band] for band in eeg_bands]
    ax = df.plot.bar(x='band', y='val', legend=False)
    ax.set_xlabel("EEG band")
    ax.set_ylabel("Mean band Amplitude")
    ax.yaxis.grid(True)
    return a1, a2, a3, a4, a5

def plot_EEG_mean_frequency_comparison(a1, a2, a3, a4, a5, b1, b2, b3, b4, b5, label1, label2):
    
    #multiple bar plot for comparison


    # data to plot
    n_groups = 5
    means_frank = (a1, a2, a3, a4, a5)
    means_guido = (b1, b2, b3, b4, b5)
    means_porthos = (0, 0, 0, 0, 0)
 
    # create plot
    fig, ax = plt.subplots()
    index = np.arange(n_groups)
    bar_width = 0.25
    opacity = 0.8

    rects1 = plt.bar(index, means_frank, bar_width,
                     alpha=opacity,
                     color='r',
                     label=label1)

    rects2 = plt.bar(index + bar_width, means_guido, bar_width,
                     alpha=opacity,
                     color='y',
                     label=label2)

    #rects3 = plt.bar(index + 2*bar_width, means_porthos, bar_width,
                     #alpha=opacity,
                     #color='b',
                     #label='Post Meditation')

    plt.xlabel('Band')
    plt.ylabel('Band Amplitude')
    plt.title('Average Frequency Band ')
    plt.xticks(index + bar_width, ('Alpha', 'Beta', 'Delta', 'Gamma', 'Theta'))
    plt.legend()
    ax.yaxis.grid(True)
 
    #plt.tight_layout()
    #plt.show()