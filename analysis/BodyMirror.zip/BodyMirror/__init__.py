# import all BodyMirror submodules that should be loaded automatically
import BodyMirror.classification
import BodyMirror.plot
import BodyMirror.signal
import BodyMirror.EEG_deep_analysis
import BodyMirror.utils
import BodyMirror.features
import BodyMirror.split
import BodyMirror.regression
import BodyMirror.unsupervised_learning

# fetch into BodyMirror-scope so that users don't have to specify the entire
# namespace
from BodyMirror.classification import classify
from BodyMirror.regression import regress
from BodyMirror.unsupervised_learning  import Clustering

# retrieve the BodyMirror version (required for package manager)
from BodyMirror.version import __version__
