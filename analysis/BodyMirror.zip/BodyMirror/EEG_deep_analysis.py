"""This module performs some deep anaylsis methods in EEG data, such as source localization. This module uses some functions from the mne open source software 
    https://mne.tools/

"""

# TODO: description above. check if we really have a filter class for every
#       filter, or if we specify them


import numpy as np
from mne.preprocessing import (ICA, create_eog_epochs, create_ecg_epochs,
                               corrmap)
import pyvista as pv

from pyvistaqt import BackgroundPlotter
import mne
import os.path as op
from mne.minimum_norm import make_inverse_operator, apply_inverse
from mne.datasets import sample
from mne import setup_volume_source_space, setup_source_space
from mne import make_forward_solution
from mne.io import read_raw_fif
from mne.minimum_norm import make_inverse_operator, apply_inverse_epochs
from mne_connectivity import spectral_connectivity_epochs
from mne.viz import circular_layout
import os
os.environ['ETS_TOOLKIT'] = 'qt4'
os.environ['QT_API'] = 'pyqt5'

os.environ['MNE_3D_OPTION_ANTIALIAS'] = 'false'
from mne.time_frequency import tfr_morlet, psd_multitaper
from mne.datasets import somato
import matplotlib.pyplot as plt 


def convert_mne(channels, patient, type_id, type_value, window_size, crop_factor, montage):
    
    """Convert numpy array data into mne object.

    This function takes a ``numpy array`` and create mne object

    Parameters
    ----------
    channels : numpy array with the EEG channels
    patient: patient data (numpy)
    type_id: a character---that could be either ``patient`` or ``control``
    type_value: integer--a unique id for the data. e.g. patient:0, control: 1
    window_size: integer--how many epochs to create from the data. e.g. for 1 min data, you can create 5 samples with window_size=12
    crop_factor: integer-- data_lenghth/window_size. For window_size=12, data_length=1 min, crop_factor=5
    montage: character-- 10_20 system


    Returns
    -------
    raw_data : Transformed mne object
    info: mne info
    events: trials 
    event_dict: dict with unique id for events

    """
    
    channels=channels.tolist()
    info=mne.create_info(ch_names=channels, sfreq=500, ch_types='eeg', verbose=None)
    raw_data = mne.io.RawArray(patient, info)
    raw_data= raw_data.set_eeg_reference('average', projection=True)
    raw_data.set_montage(montage)
    event_dict = {type_id: type_value}
    events=np.zeros((window_size, 3))

    for i in range(window_size):
        events[i, 0]=500*crop_factor*i
    events=events.astype(int)
        
    return raw_data, info, events, event_dict

     

def topographic_plot(tmin, tmax, data, events, event_dict, montage, time="peaks", animation=False, rejection=False):
    
    """plot topographic maps 

    This function takes the ``mne object`` and plot topographic maps

    Parameters
    ----------
    tmin : integer-- t_min of cropping the data 
    tmax: integer-- t_max of cropping the data 
    events: list
    event_dict: dict
    montage: character (e.g. "10_20")
    time: list of time points to visualize (default: "peaks")
    animation: True if you want to have an animated topographic maps
    rejection: True or False

    Returns
    -------
    epochs : mne format
    evoked: mne format
   
    """
    #reject_criteria = dict(eeg=150e-6) # 150 μV  
    epochs=mne.Epochs(data, events, event_id=event_dict, tmin=tmin
                    , tmax=tmax, baseline=(0, 0),  preload=True)
    if rejection==True:
        reject_criteria = dict(eeg=180e-5) # 150 μV
        epochs=mne.Epochs(data, events, event_id=event_dict, tmin=tmin
                    , tmax=tmax, reject=reject_criteria, baseline=(0, 0),  preload=True)
        
    epochs.set_montage(montage)
    fig = plt.figure(figsize=(6, 2))
    evoked = epochs.average().pick_types(eeg=True)
    evoked.plot_topomap(times=time, ch_type='eeg', cmap='Spectral_r', res=32,
                    outlines='skirt', contours=4)
    if animation==True:
        fig, anim_c3= evoked.animate_topomap('eeg', times=time,  blit=False, frame_rate=1)
        
    return epochs, evoked

def plot_frequency_topo(evoked, fmin, fmax, times, title, **kwargs):
    """plot topographic maps for different frequency bands 

    This function takes the ``mne object`` and plot topographic maps for a specific frequency band 

    Parameters
    ----------
    evoked:
    
    fmin : integer-- f_min of band 
    fmax: integer-- f_max of band
    time: list of time points to visualize (could be "peaks")
    title: character-- frequency band (e.g. "alpha")to visualize

    Returns
    -------
    topographic plots
   
    """
    evoked_copy=evoked.copy()
    evoked_copy= evoked_copy.filter(fmin, fmax, fir_design='firwin')
    fig= evoked_copy.plot_topomap(times=times, ch_type='eeg', title=title, **kwargs)
    
def eeg_power_band(epochs):
    """EEG relative power band feature extraction.

    This function takes an ``mne.Epochs`` object and creates EEG features based
    on relative power in specific frequency bands that are compatible with
    scikit-learn.

    Parameters
    ----------
    epochs : Epochs
        The data.

    Returns
    -------
    X : numpy array of shape [n_samples, 5]
        Transformed data.
    """
    # specific frequency bands
    FREQ_BANDS = {"delta": [0.5, 4.5],
                  "theta": [4.5, 8.5],
                  "alpha": [8.5, 11.5],
                  "sigma": [11.5, 15.5],
                  "beta": [15.5, 30]}

    psds, freqs = psd_welch(epochs, picks='eeg', fmin=0.5, fmax=30.)
    # Normalize the PSDs
    psds /= np.sum(psds, axis=-1, keepdims=True)

    X = []
    for fmin, fmax in FREQ_BANDS.values():
        psds_band = psds[:, :, (freqs >= fmin) & (freqs < fmax)].mean(axis=-1)
        X.append(psds_band.reshape(len(psds), -1))

    return np.concatenate(X, axis=1)


def apply_ica_mne (data, info, n_components, method = 'fastica', decim = 3 ):
    """Apply ICA to EEG.

    This function applies ICA to EEG

    Parameters
    ----------
    data : mne data 
    info: mne info 
    n_components: number of components 

    Returns
    -------
    fitted ICA
    """
    
    picks_eeg = mne.pick_types(info, meg=False, eeg=True, eog=False,
                               stim=False, exclude='bads')

    ica = ICA(n_components=n_components, method=method, random_state=97)
    ica.fit(data, picks=picks_eeg, decim=decim)
    ica.plot_sources(data)
    ica.plot_components()
    print('For artificat removal, please have a look at this: https://labeling.ucsd.edu/tutorial/labels')
    return ica

def analyze_channels(ica, data, channel):
    """Analyze specific channels

    Parameters
    ----------
    ica : fitted ICA 
    data: data to be used 
    channel: channel to be analyzed 

    Returns
    -------
    plot channel property 
    """
    
    
    ica.plot_properties(data, picks=channel)

def correct_data_ica(ica, raw_data, exclude):
    """correct data using ICA

    This function corrects data using ICA

    Parameters
    ----------
    ica: fitted ICA
    raw_data : raw mne EEG data 
    info: mne info 
    exclude: list of EEG channels to exclude  

    Returns
    -------
    reconstructed data 
    """

    ica.plot_overlay(raw_data, exclude=exclude)
    ica.exclude = exclude
    raw_data_copy = raw_data.copy()
    reconst_raw=ica.apply(raw_data_copy)
    raw_copy = raw_data.copy().crop(0, 2)
    ica.apply(raw_copy)
    raw_copy.plot()  
    return reconst_raw



def topo_deep_anaylsis(epochs):
    """Deep analysis of power 

    This function shows deep plots of EEG data

    Parameters
    ----------
    epochs: mne epochs 

    Returns
    -------
    plots of alpha, beta power 
    """
    
    freqs = np.logspace(*np.log10([6, 50]), num=8)
    n_cycles = freqs / 2.  # different number of cycle per frequency
    power, itc = tfr_morlet(epochs, freqs=freqs, n_cycles=n_cycles, use_fft=True,
                            return_itc=True, decim=3, n_jobs=1)

    fig, axis = plt.subplots(1, 2, figsize=(7, 4))
    power.plot_topomap(ch_type='eeg', tmin=0.0, tmax=5, fmin=8, fmax=12,
                        mode='logratio', axes=axis[0],
                       title='Alpha', show=False)
    power.plot_topomap(ch_type='eeg',tmin=0.0, tmax=5, fmin=25, fmax=50,
                        mode='logratio', axes=axis[1],
                       title='Beta', show=False)
    power.plot_topo( mode='logratio', title='Average power')
    mne.viz.tight_layout()
    plt.show()
    
def source_localization(evoked, inverse, subjects_dir, method, split=False, backend=False):
    """plot localized sources 

    This function plots source localized sources 

    Parameters
    ----------
    evoked: mne object
    
    inverse : inverse solution-- mne object
    subjects_dir: character--subjects_dir path 
    method: character -- could be dSPM, sLORETA
    split: show both hemi or separate 

    Returns
    -------
    source localization animated plots
   
    """
    
    snr = 3.
    lambda2 = 1. / snr ** 2
    
    stc_p2 = apply_inverse(evoked, inverse, lambda2,
                        method=method, pick_ori=None)
    if backend==True:
        
        mpl_fig = stc_p2.plot( surface='white', hemi= 'lh',  colormap='hot',transparent=True, subjects_dir=subjects_dir,time_viewer=True,
                          backend='matplotlib', verbose='error')
    else:
    
        if split==True: 
            brain = stc_p2.plot( surface='white', hemi= 'split',  colormap='hot',transparent=True, time_viewer=True, subjects_dir=subjects_dir
                               , figure=2)
        else:
            brain = stc_p2.plot( surface='white', hemi= 'both',  colormap='hot',transparent=True, time_viewer=True, subjects_dir=subjects_dir
                               , figure=2)
    
        
    

    return stc_p2



